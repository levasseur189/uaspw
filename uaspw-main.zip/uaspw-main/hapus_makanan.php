<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM makanan WHERE id = $id");
}

header("Location: kelola_makanan.php");
exit;
?>
